export default function users(defStore=[],action){    
   switch(action.type){
        case 'INCREMENT_FOLLOWERS':
                    console.log('Inside users reducer !');
                    let index = action.index;

                    //new store
                    return [
                        ...defStore.slice(0,index), 
                        {...defStore[index],followers:defStore[index].followers + 1},
                        ...defStore.slice(index+1)
                    ];                  
                     
        case 'ADD_USER' :
                    console.log('Inside users reducer !');
                    console.log(action.type)
                    return defStore; // return a new Store !

        case 'FETCH_USERS':
                    return action.response;
        default:
                return defStore; // return original Store !
    }
}