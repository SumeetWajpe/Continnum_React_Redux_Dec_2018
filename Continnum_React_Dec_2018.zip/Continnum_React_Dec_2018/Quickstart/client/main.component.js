import React from 'react';
import {Link} from 'react-router';

export default class Main extends React.Component{  
  
  componentDidMount(){
    this.props.GetUsers();
  }
  
  render(){
                    return <div className="container">
                    
<nav className="navbar navbar-inverse">
  <div className="container-fluid">
    <div className="navbar-header">
      <a className="navbar-brand" href="#">Instagram</a>
    </div>
    <ul className="nav navbar-nav">
      <li> <Link to="/"> Posts</Link></li>
      <li> <Link to="/about"> About</Link></li>  
      <li> <Link to="/users"> Users </Link></li>   

    </ul>
  </div>
</nav>
                           {React.cloneElement(this.props.children,this.props)}
                    </div>  
    }
}