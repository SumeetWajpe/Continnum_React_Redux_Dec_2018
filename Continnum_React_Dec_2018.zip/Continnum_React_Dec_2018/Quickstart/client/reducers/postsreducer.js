export default function posts(defStore=[],action){  

    switch(action.type){
        case 'ADD_POST':
                    console.log('Inside Posts Reducer !');
                    return defStore;   // return new Store ! 
        default:
                    return defStore;
    }

}