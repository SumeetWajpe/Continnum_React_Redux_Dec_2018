import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import ListOfCourses from './listofcourses.component'

class Application extends Component {
  render() {
    return <div>
<ListOfCourses
     list={['React','Node','Angular','Backbone','Vue']} />  
    </div> 
  }
}


const PI = 3.14;
export default Application;
