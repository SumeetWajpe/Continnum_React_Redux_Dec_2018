import axios from 'axios';

export function IncrementFollowers(index){
    return {
        type:'INCREMENT_FOLLOWERS',
        index:index
    }
}

export function AddUser(){
    return {
        type:'ADD_USER'
    }
}
export function RemoveUser(){
    return {
        type:'REMOVE_USER'
    }
}

export function GetUsers(){
    
    var request = axios.get('https://api.myjson.com/bins/t15w0')
    return  (dispatch) =>{
        request.then(
            (response) => dispatch(
                {type:'FETCH_USERS',
                response:response.data}
                )
        )
    }
}