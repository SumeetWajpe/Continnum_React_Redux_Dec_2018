import {connect} from  'react-redux';
import * as AllActions from './actions/actions';
import {bindActionCreators} from 'redux';
import Main from './main.component';

//expose store as props
function mapStateToProps(storeData) {
        return{
            allusers:storeData.users,
            allposts:storeData.posts
        }
}

//expose actions as props
function mapDispatchToProps(dispatcher){
            return bindActionCreators(AllActions,dispatcher)
}


var app = connect(mapStateToProps,mapDispatchToProps)(Main)
export default app;


