import {combineReducers} from 'redux';
import users from './usersreducer';
import posts from './postsreducer';

var rootReducer = combineReducers({
    users:users,
    posts:posts
});

export default rootReducer;