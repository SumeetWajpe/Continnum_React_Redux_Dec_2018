import React from 'react';

 export default class Course extends React.Component{
        render(){
            return <h3> {this.props.coursename} </h3>
        }

        componentWillUnmount(){
            console.log('Clean up..')
        }
}
