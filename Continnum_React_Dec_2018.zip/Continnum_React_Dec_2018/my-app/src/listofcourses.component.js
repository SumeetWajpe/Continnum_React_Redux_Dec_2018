import React from 'react';
import Course from './course.component';
 export default class ListOfCourses extends React.Component{
        
    constructor(props){
        super(props);
        console.log('inside ctor !');
        this.state = {
            allCourses : this.props.list
        }      
    }

    componentWillMount(){
        console.log('inside componentWillMount !');
    }

    componentDidMount(){
        // ajax request ,set Timers
        console.log('inside componentDidMount !');
    }

    shouldComponentUpdate(){
        console.log('inside shouldComponentUpdate !');
        return true;
    }

    componentWillUpdate(){
        console.log('inside componentWillUpdate !');
    }
    componentDidUpdate(){
        console.log('inside componentDidUpdate !');
    }
    componentWillUnmount(){
        console.log('Clean up..')
    }

    Clickhandler(){  
        console.log('inside handler !');

        this.setState({allCourses:
            [...this.state.allCourses,this.refs.txtCourse.value]})    
    }    

    Deletehandler(){
        // access the textbox 
        // remove from collection
        // set state !

         let theValue=this.refs.txtCourse.value;
        let newState = this.state.allCourses.filter(
            e=> e !== theValue
        );
        this.setState({allCourses:newState});

      
    }
    render(){
        console.log('inside render !');

        var coursesTobecreated = this.state.allCourses.map(
            (course,index)=> <Course coursename={course} key={index}></Course>)
            return <div className="container">
                        <h1> List Of Courses </h1>
                      New Course :  <input type="text" ref="txtCourse" />
                        <input type="button" value="Add" 
                        className="btn btn-primary"
                        onClick={this.Clickhandler.bind(this)}
                        />

                         <button className="btn btn-danger"
                         onClick={this.Deletehandler.bind(this)}
                         ><span className="glyphicon glyphicon-trash"></span>
                         </button>
                      {coursesTobecreated}
            </div> 
        }
}
