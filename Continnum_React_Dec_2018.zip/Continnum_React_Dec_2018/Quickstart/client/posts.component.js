import React from 'react';
import axios from 'axios';

export default class Posts extends React.Component{
    constructor(){
        //console.log('ctor..')
        super();
        this.state = {posts:[]}
    }
    componentDidMount(){
        //console.log('componentDidMount..')

                // make ajax request !
          let thePromise =   axios.get('https://jsonplaceholder.typicode.com/posts')
          thePromise.then(
              (response)=>{
                  console.log('Set State..')
                 this.setState({posts:response.data}) 
              },
              (err)=>console.log(err)
          );// eof then
    }    
    render(){
       // console.log('Render..')
        var postsToBeCreated = this.state.posts.map(
            (p) => <li key={p.id}>{p.title}  </li>
        )
        return (
        <div> 

            <div className="jumbotron">
                <h1> All posts </h1>
            </div>
           
          <ul>
                    {postsToBeCreated}
        </ul>  
            </div>)
    }
}