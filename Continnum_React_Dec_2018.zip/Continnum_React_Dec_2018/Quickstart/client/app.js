// Code Here
import React from 'react';
import ReactDOM from 'react-dom';
import axios from 'axios';
import Posts from './posts.component';
import Main from './main.component';
import About from './about.component';
import {Router,Route,IndexRoute,browserHistory} from 'react-router';
import Users from './users.component';
import {Provider} from 'react-redux';
import store from './store/store';
import app from './connect';
import UserDetails from './userdetails.component';

var router = <Provider store={store}>
                        <Router history={browserHistory}>
                            <Route path="/" component={app}>
                                <IndexRoute component={Posts}></IndexRoute>
                                <Route path="/about" component={About}></Route>
                                <Route path="/users" component={Users}></Route>
                                <Route path="/userdetails/:id" component={UserDetails}></Route>
                        </Route>
                        </Router>
                    </Provider>


ReactDOM.render(router, document.getElementById('content'))