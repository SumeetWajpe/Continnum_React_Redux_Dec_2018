import React from 'react';
import {Link} from 'react-router';

export default class Users extends React.Component{
  
    render(){      

        var usersToBeCreated = this.props.allusers.map(
            (u,index) => <div className="userThumbnail" key={u.id}>
                    <Link to={`/userdetails/${u.id}`}>  {u.login} </Link>   &nbsp;&nbsp;
                     <button className="btn btn-primary" 
                     onClick={this.props.IncrementFollowers.bind(this,index)}>
                     {u.followers}
                         <span className="glyphicon glyphicon-user"></span>
                     </button>
                </div>            
        )
                    return <div>
                        <h1>Users Component</h1>                        
                        {usersToBeCreated}                       
                    </div> 
    }
}