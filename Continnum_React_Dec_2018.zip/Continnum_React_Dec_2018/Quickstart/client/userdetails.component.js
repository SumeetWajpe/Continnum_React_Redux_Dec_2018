import React from 'react';

export default class UserDetails extends React.Component{
  
    render(){

         // Fetch the value from Url !
         let theUserId = this.props.params.id;        
        let currUser = this.props.allusers.find(
                 u => {
                     if(u.id  == theUserId){
                         return true;
                     }
                 }
             )      
                    return <div className=" container userDetails">
                                 <h1>{currUser.login} </h1> 
                                        <img className="img-thumbnail" src={currUser.avatar_url} 
                                             height="200px" 
                                            width="200px" />
                                <p>
                                <p>
                                 ID :  <b> {currUser.id} </b> 
                                </p>
                               User Name :    <b> {currUser.login} </b> 
                                </p>   
                                <p>
                                 Followers :  <b> {currUser.followers} </b> 
                                </p> 
                                <p>
                                 Is Admin ? :  <b> {currUser.site_admin ? 'Admin'  :'User'} </b> 
                                </p>                            
                                
                    
                                

                    </div> 
    }
}