import {createStore,applyMiddleware} from 'redux';
import rootReducer from '../reducers/rootReducer';
import users from '../data/users';
import thunk from 'redux-thunk'

// var defautStoreData = {
//     users:users,
//     posts:[{id:1,name:'Post 1'}]
// }

var store  =createStore(rootReducer,applyMiddleware(thunk));

export default store;