import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App,{PI} from './App';
import * as serviceWorker from './serviceWorker';

const AppContext = React.createContext()
class AppProvider extends React.Component {
 state = {
    number : 10,
    inc: () => {
      this.setState({number: this.state.number + 1})
    }
  }
 render() {
    return <AppContext.Provider value={this.state}>
      {this.props.children}
    </AppContext.Provider>
  }
}
const Green = () => (
  <div className="green">
     <AppContext.Consumer>
        {(context) => context.number}
      </AppContext.Consumer>
  </div>
)
const Blue = () => (
  <div className="blue">
    <AppContext.Consumer>
        {(context) => <button onClick={context.inc}>INC</button>}
      </AppContext.Consumer>
    <Green />
  </div>
)   

class Red extends React.Component {
    render() {
      return  <AppProvider> 
          <div className="red">
            <AppContext.Consumer>
              {(context) => context.number}
            </AppContext.Consumer>
            <Blue />
          </div>
      </AppProvider>
    }
  }


ReactDOM.render(<Red />, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: http://bit.ly/CRA-PWA
serviceWorker.unregister();
